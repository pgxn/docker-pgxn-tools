\i widget.sql
SELECT widget();
